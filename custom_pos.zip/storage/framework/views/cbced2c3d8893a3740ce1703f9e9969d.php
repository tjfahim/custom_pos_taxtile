

<?php $__env->startSection('main_content'); ?>
<div class="content mt-3">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">
                    Invoice #<?php echo e($invoice->invoice_number); ?>

                </h5>
                <div>
                    <a href="<?php echo e(route('admin.invoices.print', $invoice->id)); ?>" class="btn btn-info btn-sm">
                        <i class="fa fa-print"></i> Print
                    </a>
                </div>
            </div>
            <div class="card-body">
                <div class="row mb-4">
                    <div class="col-md-6">
                        <h6>Customer Info</h6>
                        <p><strong>Name:</strong> <?php echo e($invoice->customer->name); ?></p>
                        <p><strong>Phone:</strong> <?php echo e($invoice->customer->phone_number_1); ?></p>
                    </div>
                    <div class="col-md-6">
                        <h6>Invoice Info</h6>
                        <p><strong>Date:</strong> <?php echo e($invoice->invoice_date->format('M d, Y')); ?></p>
                        <p><strong>Status:</strong> 
                            <span class="badge badge-<?php echo e($invoice->payment_status == 'paid' ? 'success' : 
                                ($invoice->payment_status == 'partial' ? 'warning' : 'danger')); ?>">
                                <?php echo e(ucfirst($invoice->payment_status)); ?>

                            </span>
                        </p>
                    </div>
                </div>

                <h6>Recipient Details</h6>
                <div class="row mb-4">
                    <div class="col-md-6">
                        <p><strong>Name:</strong> <?php echo e($invoice->recipient_name); ?></p>
                        <p><strong>Merchant Order Id:</strong> <?php echo e($invoice->merchant_order_id); ?></p>
                        <p><strong>Phone:</strong> <?php echo e($invoice->recipient_phone); ?></p>
                        <?php if($invoice->recipient_secondary_phone): ?>
                        <p><strong>Secondary Phone:</strong> <?php echo e($invoice->recipient_secondary_phone); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Address:</strong> <?php echo e($invoice->recipient_address); ?></p>
                        <p><strong>Delivery Area:</strong> <?php echo e($invoice->delivery_area); ?></p>
                    </div>
                </div>

                <h6>Items</h6>
                <table class="table table-bordered mb-4">
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>Qty</th>
                            <th>Weight</th>
                            <th>Unit Price</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->item_name); ?></td>
                            <td><?php echo e($item->quantity); ?></td>
                            <td><?php echo e($item->weight); ?>g</td>
                            <td>৳<?php echo e(number_format($item->unit_price, 2)); ?></td>
                            <td>৳<?php echo e(number_format($item->total_price, 2)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="4" class="text-right"><strong>Subtotal:</strong></td>
                            <td>৳<?php echo e(number_format($invoice->subtotal, 2)); ?></td>
                        </tr>
                        <tr>
                            <td colspan="4" class="text-right"><strong>Delivery Charge:</strong></td>
                            <td>৳<?php echo e(number_format($invoice->delivery_charge, 2)); ?></td>
                        </tr>
                        <tr>
                            <td colspan="4" class="text-right"><strong>Total:</strong></td>
                            <td>৳<?php echo e(number_format($invoice->total, 2)); ?></td>
                        </tr>
                    </tfoot>
                </table>

                <div class="row">
                    <div class="col-md-6">
                        <h6>Payment Details</h6>
                        <p><strong>Paid:</strong> ৳<?php echo e(number_format($invoice->paid_amount, 2)); ?></p>
                        <p><strong>Due:</strong> ৳<?php echo e(number_format($invoice->due_amount, 2)); ?></p>
                        <?php if($invoice->payment_method): ?>
                        <p><strong>Method:</strong> <?php echo e(ucfirst($invoice->payment_method)); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <?php if($invoice->special_instructions): ?>
                        <h6>Special Instructions</h6>
                        <p><?php echo e($invoice->special_instructions); ?></p>
                        <?php endif; ?>
                        <?php if($invoice->notes): ?>
                        <h6>Notes</h6>
                        <p><?php echo e($invoice->notes); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\custom_pos\resources\views/invoices/show.blade.php ENDPATH**/ ?>