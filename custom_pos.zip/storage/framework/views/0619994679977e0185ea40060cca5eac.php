<!-- Customer Select Modal (update this section) -->
<div class="modal fade" id="customerModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Select Customer</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <input type="text" id="customerSearch" class="form-control" placeholder="Search by name or phone...">
                </div>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Phone</th>
                                <th>Address</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="customerTableBody">
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="customer-row" 
                                data-customer-id="<?php echo e($customer->id); ?>"
                                data-customer-name="<?php echo e($customer->name); ?>"
                                data-customer-phone="<?php echo e($customer->phone_number_1); ?>"
                                data-customer-phone2="<?php echo e($customer->phone_number_2); ?>"
                                data-customer-address="<?php echo e($customer->full_address); ?>"
                                data-customer-area="<?php echo e($customer->delivery_area); ?>">
                                <td><?php echo e($customer->id); ?></td>
                                <td><?php echo e($customer->name); ?></td>
                                <td><?php echo e($customer->phone_number_1); ?></td>
                                <td><?php echo e(Str::limit($customer->full_address, 30)); ?></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary select-customer">
                                        Select
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\custom_pos\resources\views/invoices/partials/customer-select.blade.php ENDPATH**/ ?>