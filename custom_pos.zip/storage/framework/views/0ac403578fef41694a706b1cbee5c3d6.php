

<?php $__env->startSection('main_content'); ?>
<div class="content mt-3">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">
                    <i class="fa fa-user-tag"></i> Role Management
                </h5>
                <a href="<?php echo e(route('admin.roles.create')); ?>" class="btn btn-primary btn-sm">
                    <i class="fa fa-plus"></i> Add New Role
                </a>
            </div>

            <div class="card-body p-2">
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <div class="table-responsive">
                    <table class="table table-sm table-hover" id="rolesTable">
                        <thead class="table-light">
                            <tr>
                                <th>SL</th>
                                <th>Role Name</th>
                                <th>Users Count</th>
                                <th>Permissions</th>
                                <th>Created At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td>
                                    <span class="badge bg-primary"><?php echo e(ucfirst($role->name)); ?></span>
                                    <?php if(in_array($role->name, ['admin', 'manager', 'staff'])): ?>
                                        <span class="badge bg-secondary badge-sm ms-1">Default</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge bg-info"><?php echo e($role->users_count); ?></span>
                                </td>
                                <td>
                                    <?php if($role->permissions->count() > 0): ?>
                                        <div class="d-flex flex-wrap gap-1">
                                            <?php $__currentLoopData = $role->permissions->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span class="badge bg-secondary badge-sm">
                                                    <?php echo e(str_replace('_', ' ', $permission->name)); ?>

                                                </span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($role->permissions->count() > 3): ?>
                                                <span class="badge bg-light text-dark">
                                                    +<?php echo e($role->permissions->count() - 3); ?> more
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    <?php else: ?>
                                        <span class="text-muted">No permissions</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($role->created_at->format('d M Y')); ?></td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <a href="<?php echo e(route('admin.roles.edit', $role->id)); ?>" 
                                           class="btn btn-warning" title="Edit">
                                            <i class="fa fa-edit"></i>
                                        </a>
                                        <?php if(!in_array($role->name, ['admin', 'manager', 'staff'])): ?>
                                        <form action="<?php echo e(route('admin.roles.destroy', $role->id)); ?>" 
                                              method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger" 
                                                    onclick="return confirm('Are you sure you want to delete this role?')"
                                                    title="Delete">
                                                <i class="fa fa-trash"></i>
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.badge-sm {
    font-size: 0.7em;
    padding: 0.25em 0.6em;
}
</style>

<script>
$(document).ready(function() {
    // Initialize DataTable
    const table = $('#rolesTable').DataTable({
        order: [[0, 'asc']],
        pageLength: 20,
        responsive: true,
        language: {
            emptyTable: 'No roles found'
        }
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\custom_pos\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>