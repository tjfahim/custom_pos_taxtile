

<?php $__env->startSection('main_content'); ?>
<div class="content mt-3">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">
                    Invoice #<?php echo e($invoice->invoice_number); ?>

                </h5>
                <div>
                    <a href="<?php echo e(route('admin.invoices.edit', $invoice->id)); ?>" class="btn btn-primary btn-sm">
                        <i class="fa fa-edit"></i> Edit
                    </a>
                    <a href="<?php echo e(route('admin.invoices.print', $invoice->id)); ?>" class="btn btn-info btn-sm">
                        <i class="fa fa-print"></i> Print
                    </a>
                    <a href="<?php echo e(route('admin.invoices.index')); ?>" class="btn btn-secondary btn-sm">
                        <i class="fa fa-arrow-left"></i> Back
                    </a>
                </div>
            </div>
            <div class="card-body">
                <div class="row mb-4">
                    <div class="col-md-6">
                        <h6>Customer Info</h6>
                        <p><strong>Name:</strong> <?php echo e($invoice->customer->name); ?></p>
                        <p><strong>Phone:</strong> <?php echo e($invoice->customer->phone_number_1); ?></p>
                        <?php if($invoice->customer->phone_number_2): ?>
                        <p><strong>Secondary Phone:</strong> <?php echo e($invoice->customer->phone_number_2); ?></p>
                        <?php endif; ?>
                        <p><strong>Address:</strong> <?php echo e($invoice->customer->full_address); ?></p>
                    </div>
                    <div class="col-md-6">
                        <h6>Invoice Info</h6>
                        <p><strong>Date:</strong> <?php echo e($invoice->invoice_date->format('M d, Y')); ?></p>
                        <p><strong>Status:</strong> 
                            <span class="badge badge-<?php echo e($invoice->status == 'confirmed' ? 'success' : 
                                ($invoice->status == 'pending' ? 'warning' : 'danger')); ?>">
                                <?php echo e(ucfirst($invoice->status)); ?>

                            </span>
                        </p>
                        <p><strong>Payment Status:</strong> 
                            <span class="badge badge-<?php echo e($invoice->payment_status == 'paid' ? 'success' : 
                                ($invoice->payment_status == 'partial' ? 'warning' : 'danger')); ?>">
                                <?php echo e(ucfirst($invoice->payment_status)); ?>

                            </span>
                        </p>
                        <?php if($invoice->merchant_order_id): ?>
                        <p><strong>Merchant Order ID:</strong> <?php echo e($invoice->merchant_order_id); ?></p>
                        <?php endif; ?>
                    </div>
                </div>

                
                <!-- Items Table -->
                <h6>Items</h6>
                <table class="table table-bordered mb-4">
                    <thead class="thead-light">
                        <tr>
                            <th>#</th>
                            <th>Item</th>
                            <th>Qty</th>
                            <th>Weight</th>
                            <th>Unit Price</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $itemTotalQuantity = 0; ?>
                        <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $itemTotalQuantity += $item->quantity; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->item_name); ?> <?php if($item->description): ?> <br><small class="text-muted"><?php echo e($item->description); ?></small> <?php endif; ?></td>
                            <td><?php echo e($item->quantity); ?></td>
                            <td><?php echo e($item->weight); ?>g</td>
                            <td>৳<?php echo e(number_format($item->unit_price, 0)); ?></td>
                            <td>৳<?php echo e(number_format($item->total_price, 0)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="2" class="text-right font-weight-bold">Total Quantity:</td>
                            <td colspan="4"><?php echo e($itemTotalQuantity); ?></td>
                        </tr>
                    </tfoot>
                </table>

                <!-- Return Items Table (if exists) -->
                <?php if($invoice->has_return_items && $invoice->returnItems->count() > 0): ?>
                <h6 class="text-danger"><i class="fa fa-undo"></i> Return Items</h6>
                <table class="table table-bordered mb-4">
                    <thead class="thead-light" style="background: #ffe6e6;">
                        <tr>
                            <th>#</th>
                            <th>Item</th>
                            <th>Qty</th>
                            <th>Weight</th>
                            <th>Unit Price</th>
                            <th>Total</th>
                            <th>Reason</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $returnTotalQuantity = 0; ?>
                        <?php $__currentLoopData = $invoice->returnItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $returnItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $returnTotalQuantity += $returnItem->quantity; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($returnItem->item_name); ?> <?php if($returnItem->description): ?> <br><small class="text-muted"><?php echo e($returnItem->description); ?></small> <?php endif; ?></td>
                            <td><?php echo e($returnItem->quantity); ?></td>
                            <td><?php echo e($returnItem->weight); ?>g</td>
                            <td>৳<?php echo e(number_format($returnItem->unit_price, 0)); ?></td>
                            <td class="text-danger">-৳<?php echo e(number_format($returnItem->total_price, 0)); ?></td>
                            <td><?php echo e(ucfirst(str_replace('_', ' ', $returnItem->return_reason ?? 'N/A'))); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="2" class="text-right font-weight-bold text-danger">Return Quantity:</td>
                            <td colspan="5" class="text-danger"><?php echo e($returnTotalQuantity); ?></td>
                        </tr>
                        <tr>
                            <td colspan="6" class="text-right font-weight-bold text-danger">Total Return Amount:</td>
                            <td class="text-danger">-৳<?php echo e(number_format($invoice->returnItems->sum('total_price'), 0)); ?></td>
                        </tr>
                    </tfoot>
                </table>
                <?php endif; ?>

                <!-- Summary Section -->
                <h6>Payment Summary</h6>
                <div class="row mb-4">
                    <div class="col-md-6">
                        <table class="table table-bordered">
                            <tr>
                                <td><strong>Items Subtotal:</strong></td>
                                <td class="text-right">৳<?php echo e(number_format($invoice->items->sum('total_price'), 0)); ?></td>
                            </tr>
                            <?php if($invoice->has_return_items && $invoice->returnItems->count() > 0): ?>
                            <tr class="text-danger">
                                <td><strong>Less Returns:</strong></td>
                                <td class="text-right">-৳<?php echo e(number_format($invoice->returnItems->sum('total_price'), 0)); ?></td>
                            </tr>
                            <?php endif; ?>
                            <tr>
                                <td><strong>Net Subtotal:</strong></td>
                                <td class="text-right">৳<?php echo e(number_format($invoice->subtotal, 0)); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Delivery Charge:</strong></td>
                                <td class="text-right">৳<?php echo e(number_format($invoice->delivery_charge, 0)); ?></td>
                            </tr>
                            <tr class="table-primary">
                                <td><strong>Grand Total:</strong></td>
                                <td class="text-right"><strong>৳<?php echo e(number_format($invoice->total, 0)); ?></strong></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <table class="table table-bordered">
                            <tr>
                                <td><strong>Paid Amount:</strong></td>
                                <td class="text-right">৳<?php echo e(number_format($invoice->paid_amount, 0)); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Due Amount:</strong></td>
                                <td class="text-right"><strong class="text-<?php echo e($invoice->due_amount > 0 ? 'danger' : 'success'); ?>">৳<?php echo e(number_format($invoice->due_amount, 0)); ?></strong></td>
                            </tr>
                            <?php if($invoice->payment_method): ?>
                            <tr>
                                <td><strong>Payment Method:</strong></td>
                                <td class="text-right"><?php echo e(ucfirst(str_replace('_', ' ', $invoice->payment_method))); ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php if($invoice->payment_details): ?>
                            <tr>
                                <td><strong>Transaction ID:</strong></td>
                                <td class="text-right"><?php echo e($invoice->payment_details); ?></td>
                            </tr>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>

                <!-- Additional Info -->
                <div class="row">
                    <div class="col-md-6">
                        <?php if($invoice->special_instructions): ?>
                        <h6>Special Instructions</h6>
                        <p class="bg-light p-2 rounded"><?php echo e($invoice->special_instructions); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <?php if($invoice->notes): ?>
                        <h6>Notes</h6>
                        <p class="bg-light p-2 rounded"><?php echo e($invoice->notes); ?></p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Created By -->
                <div class="mt-3 text-muted small">
                    <p>Created by: <?php echo e($invoice->creator->name ?? 'N/A'); ?> | Created at: <?php echo e($invoice->created_at->format('M d, Y h:i A')); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\custom_pos_taxtile\resources\views/invoices/show.blade.php ENDPATH**/ ?>