<?php $__env->startSection('main_content'); ?>

<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1><?php echo e($hasFullAccess ? 'Dashboard' : 'My Performance Dashboard'); ?></h1>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
                <ol class="breadcrumb text-right">
                    <li class="active"><?php echo e($hasFullAccess ? 'Dashboard' : 'My Dashboard'); ?></li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="content mt-3">
    
    <?php if(!$hasFullAccess): ?>
    <!-- User Welcome Card -->
    <div class="row">
        <div class="col-md-12">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h4><i class="fa fa-user-circle"></i> Welcome, <?php echo e($user->name); ?>!</h4>
                            <p class="mb-0 text-white">Here's your personal performance summary. You have created <?php echo e($totalInvoices ?? '0'); ?> confirmed invoices in total.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
<?php if($adminhasFullAccess): ?>
<!-- Summary Cards -->
<div class="row">
    <div class="col-xl-12 col-lg-12 col-md-12">
        <div class="card">
            <div class="card-body">
                <div class="stat-widget-one">

                    <!-- Icon -->
                   

                    <div class="stat-content dib" style="width:calc(100% - 70px);">

                        <!-- Title -->
                        <div class="stat-text"
                             style="font-size:22px; font-weight:800; color:#222; margin-bottom:8px;">
                            Today's Summary
                        </div>

                        <!-- Total Summary -->
                        <div class="stat-sub"
                             style="font-size:17px; font-weight:700; line-height:1.9; color:#222;">

                            <span style="color:#000;">
                                Total Sell:
                                <strong style="font-size:20px;">
                                    <?php echo e(number_format(array_sum(array_column($todayData, 'revenue')) + $todayInhouse['revenue'], 0)); ?>

                                </strong>
                                (
                                <strong style="font-size:20px;">
                                    <?php echo e(number_format(array_sum(array_column($todayData, 'quantity')) + $todayInhouse['quantity'], 0)); ?>

                                </strong>
                                )
                            </span>

                            <span style="margin-left:10px; color:#555;">|</span>

                            <span style="color:#34495e;">
                                Total Parcel:
                                <strong style="font-size:20px;">
                                    <?php echo e(array_sum(array_column($todayData, 'invoices')) + $todayInhouse['invoices']); ?>

                                </strong>
                            </span>

                            <span style="margin-left:10px; color:#555;">|</span>

                            <span style="color:#8e44ad;">
                                Price:
                                <strong style="font-size:20px;">
                                    ৳<?php echo e(number_format(array_sum(array_column($todayData, 'subtotal')) + $todayInhouse['subtotal'], 0)); ?>

                                </strong>
                            </span>

                            <span style="margin-left:10px; color:#555;">|</span>

                            <span style="color:#e67e22;">
                                Delivery:
                                <strong style="font-size:20px;">
                                    ৳<?php echo e(number_format(array_sum(array_column($todayData, 'delivery')) + $todayInhouse['delivery'], 0)); ?>

                                </strong>
                            </span>

                            <span style="margin-left:10px; color:#555;">|</span>

                            <span style="color:#27ae60;">
                                Paid:
                                <strong style="font-size:20px;">
                                    ৳<?php echo e(number_format(array_sum(array_column($todayData, 'paid')) + $todayInhouse['paid'], 0)); ?>

                                </strong>
                            </span>
                        </div>

                        <hr style="margin:15px 0; border-top:2px solid #eee;">

                        <!-- Courier Details -->
                        <?php $__currentLoopData = $todayData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courier => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php
                                $courierLower = strtolower($courier);

                                if (strpos($courierLower, 'pathao') !== false) {
                                    $courierColor = '#e74c3c';
                                    $courierBg = '#fff1f0';
                                } elseif (strpos($courierLower, 'redx') !== false) {
                                    $courierColor = '#c0392b';
                                    $courierBg = '#fff5f5';
                                } else {
                                    $courierColor = '#3498db';
                                    $courierBg = '#f0f8ff';
                                }
                            ?>

                            <div class="stat-sub"
                                 style="
                                    font-size:17px;
                                    font-weight:700;
                                    line-height:2;
                                    margin-bottom:8px;
                                    padding:8px 12px;
                                    background:<?php echo e($courierBg); ?>;
                                    border-left:5px solid <?php echo e($courierColor); ?>;
                                    border-radius:4px;
                                 ">

                                <strong style="
                                    color:<?php echo e($courierColor); ?>;
                                    font-size:20px;
                                    font-weight:900;
                                ">
                                    <?php echo e($courier); ?>

                                </strong>

                                <span style="color:#777;"> --- </span>

                                <span style="color:#222;">
                                    Qty:
                                    <strong style="font-size:19px;">
                                        <?php echo e(number_format($data['quantity'], 0)); ?>

                                    </strong>
                                </span>

                                <span style="color:#aaa;"> | </span>

                                <span style="color:#8e44ad;">
                                    Price:
                                    <strong style="font-size:19px;">
                                        ৳<?php echo e(number_format($data['subtotal'] ?? 0, 0)); ?>

                                    </strong>
                                </span>

                                <span style="color:#aaa;"> | </span>

                                <span style="color:#e67e22;">
                                    Delivery:
                                    <strong style="font-size:19px;">
                                        ৳<?php echo e(number_format($data['delivery'] ?? 0, 0)); ?>

                                    </strong>
                                </span>

                                <span style="color:#aaa;"> | </span>

                                <span style="color:#2c3e50;">
                                    Total:
                                    <strong style="font-size:20px;">
                                        ৳<?php echo e(number_format($data['revenue'], 0)); ?>

                                    </strong>
                                </span>

                                <span style="color:#aaa;"> | </span>

                                <span style="color:#27ae60;">
                                    Paid:
                                    <strong style="font-size:19px;">
                                        ৳<?php echo e(number_format($data['paid'] ?? 0, 0)); ?>

                                    </strong>
                                </span>

                                <span style="color:#aaa;"> | </span>

                                <span style="color:#34495e;">
                                    Parcels:
                                    <strong style="font-size:19px;">
                                        <?php echo e(number_format($data['invoices'] ?? 0, 0)); ?>

                                    </strong>
                                </span>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <!-- In House -->
                        <?php if($todayInhouse['invoices'] > 0): ?>

                            <hr style="margin:12px 0; border-top:2px solid #eee;">

                            <div class="stat-sub"
                                 style="
                                    font-size:17px;
                                    font-weight:700;
                                    line-height:2;
                                    padding:8px 12px;
                                    background:#edfff4;
                                    border-left:5px solid #2ecc71;
                                    border-radius:4px;
                                 ">

                                <strong style="
                                    color:#27ae60;
                                    font-size:20px;
                                    font-weight:900;
                                ">
                                    In House
                                </strong>

                                <span style="color:#777;"> --- </span>

                                <span style="color:#222;">
                                    Qty:
                                    <strong style="font-size:19px;">
                                        <?php echo e(number_format($todayInhouse['quantity'], 0)); ?>

                                    </strong>
                                </span>

                                <span style="color:#aaa;"> | </span>

                                <span style="color:#8e44ad;">
                                    Price:
                                    <strong style="font-size:19px;">
                                        ৳<?php echo e(number_format($todayInhouse['subtotal'] ?? 0, 0)); ?>

                                    </strong>
                                </span>

                                <span style="color:#aaa;"> | </span>

                                <span style="color:#e67e22;">
                                    Delivery:
                                    <strong style="font-size:19px;">
                                        ৳<?php echo e(number_format($todayInhouse['delivery'] ?? 0, 0)); ?>

                                    </strong>
                                </span>

                                <span style="color:#aaa;"> | </span>

                                <span style="color:#27ae60;">
                                    Total:
                                    <strong style="font-size:20px;">
                                        ৳<?php echo e(number_format($todayInhouse['revenue'], 0)); ?>

                                    </strong>
                                </span>

                                <span style="color:#aaa;"> | </span>

                                <span style="color:#16a085;">
                                    Paid:
                                    <strong style="font-size:19px;">
                                        ৳<?php echo e(number_format($todayInhouse['paid'] ?? 0, 0)); ?>

                                    </strong>
                                </span>

                                <span style="color:#aaa;"> | </span>

                                <span style="color:#34495e;">
                                    Parcels:
                                    <strong style="font-size:19px;">
                                        <?php echo e(number_format($todayInhouse['invoices'] ?? 0, 0)); ?>

                                    </strong>
                                </span>
                            </div>

                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

  

    <?php if($adminhasFullAccess): ?>
    <!-- Today's Payments -->
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12">
            <div class="card">
                <div class="card-header">
                    <i class="fa fa-credit-card text-success"></i> Today's Payments Transaction Details
                    <span class="badge bg-success float-right"><?php echo e($todayPaidInvoices->count()); ?> payments</span>
                </div>
                <div class="card-body">
                    <!-- Creator Summary -->
                    <?php if(isset($creatorPaymentSummary) && $creatorPaymentSummary->count() > 0): ?>
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <div class="alert alert-info">
                                <strong><i class="fa fa-users"></i> Payment Summary by Creator:</strong>
                                <div class="row mt-2">
                                    <div class="col-md-3">
                                        <strong>Total Payments:</strong> 
                                        <span class="badge bg-primary"><?php echo e($todayPaidInvoices->count()); ?></span>
                                    </div>
                                    <?php $__currentLoopData = $creatorPaymentSummary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $creatorId => $summary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3">
                                        <strong><?php echo e($summary['creator_name']); ?>:</strong> 
                                        <span class="badge bg-success"><?php echo e($summary['invoice_count']); ?></span>
                                        <span class="text-muted">(৳<?php echo e(number_format($summary['total_paid'], 0)); ?>)</span>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <div style="max-height: 450px; overflow-y: auto;">
                        <table class="table table-sm table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Invoice</th>
                                    <th>Phone</th>
                                    <th>Created By</th>
                                    <th>Merchant Id</th>
                                    <th class="text-end">Price</th>
                                    <th class="text-end">Delivery</th>
                                    <th class="text-end">Total</th>
                                    <th class="text-end">Paid</th>
                                    <th class="text-end">Due</th>
                                    <th class="text-center">Method</th>
                                    <th class="text-center">Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $todayPaidInvoices->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <strong>#<?php echo e($invoice->invoice_number ?? $invoice->id); ?></strong>
                                    </td>
                                    <td>
                                        <strong><?php echo e($invoice->recipient_phone); ?></strong>
                                    </td>
                                    <td>
                                        <span class="badge bg-info">
                                            <?php echo e($invoice->creator ? $invoice->creator->name : 'N/A'); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <span style="font-size: 12px;">
                                            <?php echo e($invoice->merchant_order_id ?? 'N/A'); ?>

                                        </span>
                                    </td>
                                    <td class="text-end">৳<?php echo e(number_format($invoice->subtotal, 0)); ?></td>
                                    <td class="text-end">৳<?php echo e(number_format($invoice->delivery_charge, 0)); ?></td>
                                    <td class="text-end fw-bold">৳<?php echo e(number_format($invoice->total, 0)); ?></td>
                                    <td class="text-end text-success fw-bold">৳<?php echo e(number_format($invoice->paid_amount, 0)); ?></td>
                                    <td class="text-end text-danger">৳<?php echo e(number_format($invoice->due_amount, 0)); ?></td>
                                    <td class="text-center">
                                        <?php if($invoice->payment_method): ?>
                                            <span class="badge" style="background: #3498db; color: #fff; font-size: 10px;">
                                                <?php echo e($invoice->payment_method); ?>

                                            </span>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <?php if($invoice->payment_details): ?>
                                            <span style="font-size: 11px; color: #666;"><?php echo e($invoice->payment_details); ?></span>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="11" class="text-center text-muted py-3">
                                        <i class="fa fa-inbox" style="font-size: 20px; display: block; margin-bottom: 5px;"></i>
                                        No payments received today
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                            <tfoot>
                                <tr style="border-top: 2px solid #e9ecef; font-weight: bold; background: #f8f9fa;">
                                    <td colspan="4" class="text-end">TOTAL:</td>
                                    <td class="text-end">৳<?php echo e(number_format($todayPaidInvoices->sum('subtotal'), 0)); ?></td>
                                    <td class="text-end">৳<?php echo e(number_format($todayPaidInvoices->sum('delivery_charge'), 0)); ?></td>
                                    <td class="text-end">৳<?php echo e(number_format($todayPaidInvoices->sum('total'), 0)); ?></td>
                                    <td class="text-end text-success">৳<?php echo e(number_format($todayPaidInvoices->sum('paid_amount'), 0)); ?></td>
                                    <td class="text-end text-danger">৳<?php echo e(number_format($todayPaidInvoices->sum('due_amount'), 0)); ?></td>
                                    <td colspan="2"></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    <?php if($todayPaidInvoices->count() > 10): ?>
                        <div class="text-center text-muted mt-2" style="font-size: 12px;">
                            <i class="fa fa-chevron-down"></i> Showing 10 of <?php echo e($todayPaidInvoices->count()); ?> payments
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>


    <?php if($adminhasFullAccess): ?>
    <!-- Payment Method Breakdown - Today & This Month -->
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-success text-white">
                    <i class="fa fa-credit-card"></i>
                    <strong>Today's Payment Methods</strong>
                    <span class="float-right badge bg-light text-dark">
                        Total: <?php echo e(array_sum(array_column($todayPaymentMethods, 'transactions'))); ?> Transactions
                    </span>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm table-bordered">
                            <thead class="table-light">
                                <tr>
                                    <th>Payment Method</th>
                                    <th class="text-center">Transactions</th>
                                    <th class="text-end">Total Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $methodLabels = [
                                    'bkash' => 'bKash (Merchant)',
                                    'bkash_personal' => 'bKash (Personal)',
                                    'bank_transfer' => 'Bank Transfer',
                                    'cash' => 'Cash'
                                ]; ?>
                                
                                <?php $__currentLoopData = $todayPaymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($data['transactions'] > 0): ?>
                                    <tr>
                                        <td>
                                            <span class="badge" style="background: #3498db; color: #fff; padding: 6px 10px;">
                                                <?php echo e($methodLabels[$method] ?? ucfirst(str_replace('_', ' ', $method))); ?>

                                            </span>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-primary"><?php echo e($data['transactions']); ?></span>
                                        </td>
                                        <td class="text-end text-success fw-bold">
                                            ৳<?php echo e(number_format($data['total_paid'], 0)); ?>

                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                <?php if(array_sum(array_column($todayPaymentMethods, 'transactions')) == 0): ?>
                                <tr>
                                    <td colspan="3" class="text-center text-muted py-3">
                                        <i class="fa fa-inbox"></i> No payments today
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                            <tfoot class="table-secondary">
                                <tr>
                                    <th>TOTAL</th>
                                    <th class="text-center"><?php echo e(array_sum(array_column($todayPaymentMethods, 'transactions'))); ?></th>
                                    <th class="text-end">৳<?php echo e(number_format(array_sum(array_column($todayPaymentMethods, 'total_paid')), 0)); ?></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <i class="fa fa-calendar"></i>
                    <strong>This Month's Payment Methods</strong>
                    <span class="float-right badge bg-light text-dark">
                        Total: <?php echo e(array_sum(array_column($monthlyPaymentMethods, 'transactions'))); ?> Transactions
                    </span>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm table-bordered">
                            <thead class="table-light">
                                <tr>
                                    <th>Payment Method</th>
                                    <th class="text-center">Transactions</th>
                                    <th class="text-end">Total Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $methodLabels = [
                                    'bkash' => 'bKash (Merchant)',
                                    'bkash_personal' => 'bKash (Personal)',
                                    'bank_transfer' => 'Bank Transfer',
                                    'cash' => 'Cash'
                                ]; ?>
                                
                                <?php $__currentLoopData = $monthlyPaymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($data['transactions'] > 0): ?>
                                    <tr>
                                        <td>
                                            <span class="badge" style="background: #3498db; color: #fff; padding: 6px 10px;">
                                                <?php echo e($methodLabels[$method] ?? ucfirst(str_replace('_', ' ', $method))); ?>

                                            </span>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-primary"><?php echo e($data['transactions']); ?></span>
                                        </td>
                                        <td class="text-end text-success fw-bold">
                                            ৳<?php echo e(number_format($data['total_paid'], 0)); ?>

                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                <?php if(array_sum(array_column($monthlyPaymentMethods, 'transactions')) == 0): ?>
                                <tr>
                                    <td colspan="3" class="text-center text-muted py-3">
                                        <i class="fa fa-inbox"></i> No payments this month
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                            <tfoot class="table-secondary">
                                <tr>
                                    <th>TOTAL</th>
                                    <th class="text-center"><?php echo e(array_sum(array_column($monthlyPaymentMethods, 'transactions'))); ?></th>
                                    <th class="text-end">৳<?php echo e(number_format(array_sum(array_column($monthlyPaymentMethods, 'total_paid')), 0)); ?></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
 <?php if($adminhasFullAccess): ?>
<!-- Monthly Attendance Calendar -->
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <strong class="card-title">
                    <i class="fa fa-calendar mr-2"></i>
                    Attendance - <?php echo e($monthName); ?>

                </strong>
                <span class="float-right badge bg-info">
                    <?php echo e(isset($attendanceMatrix) && is_array($attendanceMatrix) ? count($attendanceMatrix) : 0); ?> Staff Members
                </span>
            </div>
            <div class="card-body">
                <?php if(isset($attendanceMatrix) && is_array($attendanceMatrix) && count($attendanceMatrix) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover table-sm" id="attendanceTable">
                        <thead class="thead-light">
                            <tr>
                                <th style="min-width: 100px; position: sticky; left: 0; background: #343a40; z-index: 10;">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span>User</span>
                                    </div>
                                </th>
                                <?php for($day = 1; $day <= $daysInMonth; $day++): ?>
                                    <?php
                                        $date = Carbon\Carbon::create($attYear, $attMonth, $day);
                                        $isFriday = $date->isFriday();
                                        $isToday = $date->isToday();
                                        $dayOfWeek = $date->format('D');
                                    ?>
                                    <th class="text-center <?php echo e($isFriday ? 'table-secondary' : ''); ?> <?php echo e($isToday ? 'table-primary' : ''); ?>" 
                                        style="min-width: 40px;">
                                        <div>
                                            <div><?php echo e($day); ?></div>
                                          
                                        </div>
                                    </th>
                                <?php endfor; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $attendanceMatrix; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="position: sticky; left: 0; background: white; z-index: 5; min-width: 180px;">
    <div class="d-flex align-items-center">
        <div class="avatar-circle bg-info text-white mr-2" 
             style="width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 11px; flex-shrink: 0;">
            <?php echo e(strtoupper(substr($userData['name'], 0, 2))); ?>

        </div>
        <div>
            <div class="font-weight-bold"><?php echo e($userData['name'] ?? 'Unknown'); ?></div>
            <div style="font-size: 14px; line-height: 1.2;">
                <?php if($userData['late_count'] > 0 || $userData['absent_count'] > 0): ?>
                    <?php if($userData['late_count'] > 0): ?>
                        <span class="text-warning">Late: <?php echo e($userData['late_count']); ?></span>
                    <?php endif; ?>
                    <?php if($userData['absent_count'] > 0): ?>
                        <?php if($userData['late_count'] > 0): ?>
                            <span class="text-muted"> | </span>
                        <?php endif; ?>
                        <span class="text-danger">Absent: <?php echo e($userData['absent_count']); ?></span>
                    <?php endif; ?>
                <?php else: ?>
                    <span class="text-muted">No absences</span>
                <?php endif; ?>
            </div>
        </div>
    </div>
</td>
                                    
                                    <?php for($day = 1; $day <= $daysInMonth; $day++): ?>
                                        <?php
                                            $date = Carbon\Carbon::create($attYear, $attMonth, $day);
                                            $isFriday = $date->isFriday();
                                            $dayData = $userData['days'][$day] ?? null;
                                            $status = $dayData ? $dayData['status'] : null;
                                            $inTime = $dayData ? $dayData['in_time'] : null;
                                            $onLeave = $dayData ? $dayData['on_leave'] : false;
                                            $isHoliday = $dayData ? $dayData['is_govt_holiday'] : false;
                                            $attendanceId = $dayData ? $dayData['id'] : null;
                                        ?>
                                        <td class="text-center attendance-cell <?php echo e($isFriday ? 'bg-light' : ''); ?> <?php echo e($isHoliday ? 'bg-warning bg-opacity-25' : ''); ?>"
                                            style="cursor: default;">
                                            <?php if($status): ?>
                                                <?php if($status == 'leave'): ?>
                                                    <span class="badge badge-dark" title="On Leave">L</span>
                                                <?php elseif($status == 'holiday'): ?>
                                                    <span class="badge badge-primary" title="Holiday">H</span>
                                                <?php elseif($status == 'friday'): ?>
                                                    <span class="badge badge-secondary" title="Friday">F</span>
                                                <?php elseif($status == 'present'): ?>
                                                    <span class="badge badge-success" title="Present: <?php echo e($inTime); ?>">
                                                        <i class="fa fa-check"></i> <?php echo e($inTime ? Carbon\Carbon::parse($inTime)->format('h:i A') : ''); ?>

                                                    </span>
                                                <?php elseif($status == 'late'): ?>
                                                    <span class="badge badge-warning" title="Late: <?php echo e($inTime); ?>">
                                                        <i class="fa fa-clock-o"></i> <?php echo e($inTime ? Carbon\Carbon::parse($inTime)->format('h:i A') : ''); ?>

                                                    </span>
                                                <?php elseif($status == 'absent'): ?>
                                                    <span class="badge badge-danger" title="Absent">A</span>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                    <?php endfor; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="mt-3">
                    <span class="badge badge-success">P = Present</span>
                    <span class="badge badge-warning">L = Late</span>
                    <span class="badge badge-danger">A = Absent</span>
                    <span class="badge badge-dark">Lv = Leave</span>
                    <span class="badge badge-primary">H = Holiday</span>
                    <span class="badge badge-secondary">F = Friday</span>
                    <span class="text-muted ml-3"><small>Late after 11:30 AM</small></span>
                </div>
                <?php else: ?>
                <div class="text-center py-4">
                    <i class="fa fa-inbox fa-3x text-muted"></i>
                    <p class="text-muted mt-2">No attendance data available for this month</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
    <?php if(!$adminhasFullAccess): ?>
 <div class="row">

    
    <div class="col-lg-6 mb-4">
        <div class="card h-100">
            <div class="card-header bg-primary text-white">
                <strong>
                    <i class="fa fa-calendar-day"></i>
                    Today's Summary
                </strong>
            </div>

            <div class="card-body">
                <div class="row">

                    <div class="col-6 mb-3">
                        <div class="text-center p-3 border rounded">
                            <h5 class="text-primary">
                                <?php echo e(number_format($todayInvoices ?? 0)); ?>

                            </h5>
                            <small>Invoices</small>
                        </div>
                    </div>

                    <div class="col-6 mb-3">
                        <div class="text-center p-3 border rounded">
                            <h5 class="text-success">
                                <?php echo e(number_format($todayQuantity ?? 0)); ?>

                            </h5>
                            <small>Quantity</small>
                        </div>
                    </div>

                    <div class="col-6 mb-3">
                        <div class="text-center p-3 border rounded">
                            <h5>
                                ৳<?php echo e(number_format($todaySubtotal ?? 0, 0)); ?>

                            </h5>
                            <small>Total Price</small>
                        </div>
                    </div>

                    <div class="col-6 mb-3">
                        <div class="text-center p-3 border rounded">
                            <h5 class="text-info">
                                ৳<?php echo e(number_format($todayDelivery ?? 0, 0)); ?>

                            </h5>
                            <small>Delivery</small>
                        </div>
                    </div>

                    <div class="col-12 mb-3">
                        <div class="text-center p-3 border rounded bg-light">
                            <h4 class="text-primary">
                                ৳<?php echo e(number_format($todayRevenue ?? 0, 0)); ?>

                            </h4>
                            <small>Total Amount</small>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="text-center p-3 border rounded">
                            <h5 class="text-success">
                                ৳<?php echo e(number_format($todayPaid ?? 0, 0)); ?>

                            </h5>
                            <small>Total Paid</small>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="text-center p-3 border rounded">
                            <h5 class="text-warning">
                                ৳<?php echo e(number_format($todayDue ?? 0, 0)); ?>

                            </h5>
                            <small>Total Due</small>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>


    
    <div class="col-lg-6 mb-4">
        <div class="card h-100">
            <div class="card-header bg-success text-white">
                <strong>
                    <i class="fa fa-calendar-alt"></i>
                    This Month's Summary
                </strong>
            </div>

            <div class="card-body">
                <div class="row">

                    <div class="col-6 mb-3">
                        <div class="text-center p-3 border rounded">
                            <h5 class="text-primary">
                                <?php echo e(number_format($monthlyInvoices ?? 0)); ?>

                            </h5>
                            <small>Invoices</small>
                        </div>
                    </div>

                    <div class="col-6 mb-3">
                        <div class="text-center p-3 border rounded">
                            <h5 class="text-success">
                                <?php echo e(number_format($monthlyQuantity ?? 0)); ?>

                            </h5>
                            <small>Quantity</small>
                        </div>
                    </div>

                    <div class="col-6 mb-3">
                        <div class="text-center p-3 border rounded">
                            <h5>
                                ৳<?php echo e(number_format($monthlySubtotal ?? 0, 0)); ?>

                            </h5>
                            <small>Total Price</small>
                        </div>
                    </div>

                    <div class="col-6 mb-3">
                        <div class="text-center p-3 border rounded">
                            <h5 class="text-info">
                                ৳<?php echo e(number_format($monthlyDelivery ?? 0, 0)); ?>

                            </h5>
                            <small>Delivery</small>
                        </div>
                    </div>

                    <div class="col-12 mb-3">
                        <div class="text-center p-3 border rounded bg-light">
                            <h4 class="text-success">
                                ৳<?php echo e(number_format($monthlyRevenue ?? 0, 0)); ?>

                            </h4>
                            <small>Total Amount</small>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="text-center p-3 border rounded">
                            <h5 class="text-success">
                                ৳<?php echo e(number_format($monthlyPaid ?? 0, 0)); ?>

                            </h5>
                            <small>Total Paid</small>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="text-center p-3 border rounded">
                            <h5 class="text-warning">
                                ৳<?php echo e(number_format($monthlyDue ?? 0, 0)); ?>

                            </h5>
                            <small>Total Due</small>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

</div>
    <?php endif; ?>

    <!-- Status Charts Row (Only for Admin) -->
    <?php if($adminhasFullAccess && isset($invoiceStatusCounts)): ?>
    <div class="row">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-body">
                    <h4 class="mb-3">Invoice Status (All Invoices)</h4>
                    <canvas id="invoiceStatusChart" height="150"></canvas>
                </div>
            </div>
        </div>
        
        <div class="col-lg-6">
            <div class="card">
                <div class="card-body">
                    <h4 class="mb-3">Payment Status (Confirmed Invoices)</h4>
                    <canvas id="paymentStatusChart" height="150"></canvas>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    

    <?php if($adminhasFullAccess): ?>
    <div class="row">
        <div class="col-md-12">
            <!-- Today's Team Performance -->
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <i class="fa fa-users me-1"></i>
                    <strong>Team Members Performance</strong>
                    <span class="float-right badge bg-light text-dark">Today's Performance</span>
                </div>
                <div class="card-body">
                    <?php if($todayPerformance->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead class="table-dark">
                                    <tr>
                                        <th>#</th>
                                        <th>Team Member</th>
                                        <th>Email</th>
                                        <th class="text-center">Memo</th>
                                        <th class="text-center">Quantity</th>
                                        <th class="text-end">Price</th>
                                        <th class="text-end">Delivery</th>
                                        <th class="text-end">Total</th>
                                        <th class="text-end">Paid</th>
                                        <th class="text-end">Due</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $todayPerformance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td>
                                            <strong><?php echo e($member->name); ?></strong>
                                            <?php if($index == 0): ?>
                                                <span class="badge bg-warning ms-1">
                                                    <i class="fa fa-trophy"></i> Top
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($member->email); ?></td>
                                        <td class="text-center">
                                            <span class="badge bg-primary"><?php echo e($member->total_invoices); ?></span>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-info"><?php echo e(number_format($member->total_quantity)); ?></span>
                                        </td>
                                        <td class="text-end">৳<?php echo e(number_format($member->total_subtotal, 0)); ?></td>
                                        <td class="text-end">৳<?php echo e(number_format($member->total_delivery, 0)); ?></td>
                                        <td class="text-end fw-bold">৳<?php echo e(number_format($member->total_amount, 0)); ?></td>
                                        <td class="text-end text-success">৳<?php echo e(number_format($member->total_paid, 0)); ?></td>
                                        <td class="text-end text-danger">৳<?php echo e(number_format($member->total_due, 0)); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="fa fa-info-circle fa-3x text-muted"></i>
                            <p class="text-muted mt-2">No team activity today</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php if($adminhasFullAccess): ?>
    <?php if(isset($topCreators) && $topCreators->count() > 0): ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <i class="fa fa-users me-1"></i>
                    <strong>Creators Performance </strong>
                    <span class="float-right badge bg-light text-dark">Today's Performance</span>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th>#</th>
                                    <th>Creator Name</th>
                                    <th>Email</th>
                                    <th class="text-center">Memo</th>
                                    <th class="text-center">Quantity</th>
                                    <th class="text-end">Price</th>
                                    <th class="text-end">Delivery</th>
                                    <th class="text-end">Total</th>
                                    <th class="text-end">Paid</th>
                                    <th class="text-end">Due</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $topCreators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $creator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><strong><?php echo e($creator->name); ?></strong></td>
                                    <td><?php echo e($creator->email); ?></td>
                                    <td class="text-center"><span class="badge bg-primary"><?php echo e($creator->total_invoices); ?></span></td>
                                    <td class="text-center"><span class="badge bg-info"><?php echo e(number_format($creator->total_quantity)); ?></span></td>
                                    <td class="text-end">৳<?php echo e(number_format($creator->total_subtotal, 0)); ?></td>
                                    <td class="text-end">৳<?php echo e(number_format($creator->total_delivery, 0)); ?></td>
                                    <td class="text-end">৳<?php echo e(number_format($creator->total_amount, 0)); ?></td>
                                    <td class="text-end text-success">৳<?php echo e(number_format($creator->total_paid, 0)); ?></td>
                                    <td class="text-end text-danger">৳<?php echo e(number_format($creator->total_due, 0)); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php endif; ?>

    <?php if($adminhasFullAccess && isset($last10Days)): ?>
    <!-- Last 10 Days Breakdown -->
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <strong class="card-title">Last 10 Days Performance </strong>
                    <span class="float-right badge bg-info">Paid vs Due Comparison</span>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm table-bordered">
                            <thead class="table-light">
                                <tr>
                                    <th>Date</th>
                                    <th class="text-center">Invoices</th>
                                    <th class="text-center">Quantity</th>
                                    <th class="text-end">Price</th>
                                    <th class="text-end">Delivery</th>
                                    <th class="text-end">Total</th>
                                    <th class="text-end">Paid</th>
                                    <th class="text-end">Due</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $last10Days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($day['date']); ?></td>
                                    <td class="text-center"><?php echo e($day['count']); ?></td>
                                    <td class="text-center"><?php echo e(number_format($day['quantity'])); ?></td>
                                    <td class="text-end">৳<?php echo e(number_format($day['subtotal'], 0)); ?></td>
                                    <td class="text-end">৳<?php echo e(number_format($day['delivery'], 0)); ?></td>
                                    <td class="text-end">৳<?php echo e(number_format($day['revenue'], 0)); ?></td>
                                    <td class="text-end text-success">৳<?php echo e(number_format($day['paid'], 0)); ?></td>
                                    <td class="text-end text-danger">৳<?php echo e(number_format($day['due'], 0)); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <?php
                                $total10DaysRevenue = collect($last10Days)->sum('revenue');
                                $total10DaysPaid = collect($last10Days)->sum('paid');
                                $total10DaysDue = collect($last10Days)->sum('due');
                                $total10DaysSubtotal = collect($last10Days)->sum('subtotal');
                                $total10DaysDelivery = collect($last10Days)->sum('delivery');
                            ?>
                            <tfoot class="table-info">
                                <tr>
                                    <th>10 Days Total</th>
                                    <th class="text-center"><?php echo e(collect($last10Days)->sum('count')); ?></th>
                                    <th class="text-center"><?php echo e(number_format(collect($last10Days)->sum('quantity'))); ?></th>
                                    <th class="text-end">৳<?php echo e(number_format($total10DaysSubtotal, 0)); ?></th>
                                    <th class="text-end">৳<?php echo e(number_format($total10DaysDelivery, 0)); ?></th>
                                    <th class="text-end">৳<?php echo e(number_format($total10DaysRevenue, 0)); ?></th>
                                    <th class="text-end text-success">৳<?php echo e(number_format($total10DaysPaid, 0)); ?></th>
                                    <th class="text-end text-danger">৳<?php echo e(number_format($total10DaysDue, 0)); ?></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php if($adminhasFullAccess): ?>

    <!-- Monthly Performance Chart (Jan - Dec) -->
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <strong class="card-title"><?php echo e($adminhasFullAccess ? 'Monthly Performance ' . date('Y') : 'My Monthly Performance (Confirmed) ' . date('Y')); ?></strong>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-sm">
                            <thead class="table-primary">
                                <tr>
                                    <th>Month</th>
                                    <th class="text-center">Invoices</th>
                                    <th class="text-center">Quantity</th>
                                    <th class="text-end">Price</th>
                                    <th class="text-end">Delivery</th>
                                    <th class="text-end">Total</th>
                                    <th class="text-end">Paid</th>
                                    <th class="text-end">Due</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                                ?>
                                <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $monthName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $monthNum = $index + 1;
                                        $stats = $monthlyStats[$monthNum] ?? null;
                                    ?>
                                    <tr>
                                        <td><strong><?php echo e($monthName); ?></strong></td>
                                        <td class="text-center"><?php echo e($stats ? number_format($stats->total_invoices) : '0'); ?></td>
                                        <td class="text-center"><?php echo e($stats ? number_format($stats->total_quantity ?? 0) : '0'); ?></td>
                                        <td class="text-end">৳<?php echo e($stats ? number_format($stats->total_subtotal ?? 0, 0) : '0'); ?></td>
                                        <td class="text-end">৳<?php echo e($stats ? number_format($stats->total_delivery ?? 0, 0) : '0'); ?></td>
                                        <td class="text-end">৳<?php echo e($stats ? number_format($stats->total_revenue, 0) : '0'); ?></td>
                                        <td class="text-end text-success">৳<?php echo e($stats ? number_format($stats->total_paid, 0) : '0'); ?></td>
                                        <td class="text-end text-danger">৳<?php echo e($stats ? number_format($stats->total_due, 0) : '0'); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot class="table-secondary">
                                <?php
                                    $yearTotal = collect($monthlyStats)->sum('total_revenue');
                                    $yearPaid = collect($monthlyStats)->sum('total_paid');
                                    $yearDue = collect($monthlyStats)->sum('total_due');
                                    $yearQuantity = collect($monthlyStats)->sum('total_quantity');
                                    $yearSubtotal = collect($monthlyStats)->sum('total_subtotal');
                                    $yearDelivery = collect($monthlyStats)->sum('total_delivery');
                                ?>
                                <tr>
                                    <th>Year Total</th>
                                    <th class="text-center"><?php echo e(collect($monthlyStats)->sum('total_invoices')); ?></th>
                                    <th class="text-center"><?php echo e(number_format($yearQuantity)); ?></th>
                                    <th class="text-end">৳<?php echo e(number_format($yearSubtotal, 0)); ?></th>
                                    <th class="text-end">৳<?php echo e(number_format($yearDelivery, 0)); ?></th>
                                    <th class="text-end">৳<?php echo e(number_format($yearTotal, 0)); ?></th>
                                    <th class="text-end text-success">৳<?php echo e(number_format($yearPaid, 0)); ?></th>
                                    <th class="text-end text-danger">৳<?php echo e(number_format($yearDue, 0)); ?></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php if($adminhasFullAccess): ?>
    <?php if(isset($topCreatorsMonth) && $topCreatorsMonth->count() > 0): ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <i class="fa fa-users me-1"></i>
                    <strong>Creators Performance Monthly</strong>
                    <span class="float-right badge bg-light text-dark">This Month Performance</span>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th>#</th>
                                    <th>Creator Name</th>
                                    <th>Email</th>
                                    <th class="text-center">Memo</th>
                                    <th class="text-center">Quantity</th>
                                    <th class="text-end">Price</th>
                                    <th class="text-end">Delivery</th>
                                    <th class="text-end">Total</th>
                                    <th class="text-end">Paid</th>
                                    <th class="text-end">Due</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $topCreatorsMonth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $creator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><strong><?php echo e($creator->name); ?></strong></td>
                                    <td><?php echo e($creator->email); ?></td>
                                    <td class="text-center"><span class="badge bg-primary"><?php echo e($creator->total_invoices); ?></span></td>
                                    <td class="text-center"><span class="badge bg-info"><?php echo e(number_format($creator->total_quantity)); ?></span></td>
                                    <td class="text-end">৳<?php echo e(number_format($creator->total_subtotal, 0)); ?></td>
                                    <td class="text-end">৳<?php echo e(number_format($creator->total_delivery, 0)); ?></td>
                                    <td class="text-end">৳<?php echo e(number_format($creator->total_amount, 0)); ?></td>
                                    <td class="text-end text-success">৳<?php echo e(number_format($creator->total_paid, 0)); ?></td>
                                    <td class="text-end text-danger">৳<?php echo e(number_format($creator->total_due, 0)); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php endif; ?>

    <?php if($adminhasFullAccess): ?>
    <div class="row">
        <div class="col-md-12">
            <!-- Monthly Team Performance -->
            <div class="card mt-4">
                <div class="card-header bg-success text-white">
                    <i class="fa fa-users me-1"></i>
                    <strong>Team Members Performance Monthly</strong>
                    <span class="float-right badge bg-light text-dark">This Month Performance</span>
                </div>
                <div class="card-body">
                    <?php if($monthPerformance->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead class="table-dark">
                                    <tr>
                                        <th>#</th>
                                        <th>Team Member</th>
                                        <th>Email</th>
                                        <th class="text-center">Memo</th>
                                        <th class="text-center">Quantity</th>
                                        <th class="text-end">Price</th>
                                        <th class="text-end">Delivery</th>
                                        <th class="text-end">Total</th>
                                        <th class="text-end">Paid</th>
                                        <th class="text-end">Due</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $monthPerformance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td>
                                            <strong><?php echo e($member->name); ?></strong>
                                            <?php if($index == 0): ?>
                                                <span class="badge bg-warning ms-1">
                                                    <i class="fa fa-trophy"></i> Top
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($member->email); ?></td>
                                        <td class="text-center">
                                            <span class="badge bg-primary"><?php echo e($member->total_invoices); ?></span>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-info"><?php echo e(number_format($member->total_quantity)); ?></span>
                                        </td>
                                        <td class="text-end">৳<?php echo e(number_format($member->total_subtotal, 0)); ?></td>
                                        <td class="text-end">৳<?php echo e(number_format($member->total_delivery, 0)); ?></td>
                                        <td class="text-end fw-bold">৳<?php echo e(number_format($member->total_amount, 0)); ?></td>
                                        <td class="text-end text-success">৳<?php echo e(number_format($member->total_paid, 0)); ?></td>
                                        <td class="text-end text-danger">৳<?php echo e(number_format($member->total_due, 0)); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="fa fa-info-circle fa-3x text-muted"></i>
                            <p class="text-muted mt-2">No team activity this month</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
 
    <?php if($adminhasFullAccess): ?>
    <!-- Monthly Courier-wise Report -->
    <div class="row mt-3">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <i class="fa fa-truck me-1"></i>
                    <strong>Monthly Courier-wise Report - <?php echo e(date('F Y')); ?></strong>
                    <span class="float-right badge bg-light text-dark">Total: <?php echo e(array_sum(array_column($monthlyCourierReport, 'parcels')) + $monthlyInhouseReport['parcels']); ?> Parcels</span>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th>#</th>
                                    <th>Courier Name</th>
                                    <th class="text-center">Parcels</th>
                                    <th class="text-center">Quantity</th>
                                    <th class="text-end">Price</th>
                                    <th class="text-end">Delivery</th>
                                    <th class="text-end">Total</th>
                                    <th class="text-end">Paid</th>
                                    <th class="text-end">Due</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $counter = 1; ?>
                                
                                <?php $__currentLoopData = $monthlyCourierReport; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courier => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($data['parcels'] > 0): ?>
                                    <tr>
                                        <td><?php echo e($counter++); ?></td>
                                        <td><strong><?php echo e($courier); ?></strong></td>
                                        <td class="text-center"><span class="badge bg-primary"><?php echo e($data['parcels']); ?></span></td>
                                        <td class="text-center"><span class="badge bg-info"><?php echo e(number_format($data['quantity'])); ?></span></td>
                                        <td class="text-end">৳<?php echo e(number_format($data['subtotal'], 0)); ?></td>
                                        <td class="text-end">৳<?php echo e(number_format($data['delivery'], 0)); ?></td>
                                        <td class="text-end fw-bold">৳<?php echo e(number_format($data['total'], 0)); ?></td>
                                        <td class="text-end text-success fw-bold">৳<?php echo e(number_format($data['paid'], 0)); ?></td>
                                        <td class="text-end text-danger fw-bold">৳<?php echo e(number_format($data['due'], 0)); ?></td>
                                    </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                <!-- In-house Row -->
                                <?php if($monthlyInhouseReport['parcels'] > 0): ?>
                                <tr style="background-color: #f0f8ff; border-top: 2px solid #007bff;">
                                    <td><?php echo e($counter++); ?></td>
                                    <td><strong style="color: #2ecc71;">🏠 In House</strong></td>
                                    <td class="text-center"><span class="badge bg-success"><?php echo e($monthlyInhouseReport['parcels']); ?></span></td>
                                    <td class="text-center"><span class="badge bg-info"><?php echo e(number_format($monthlyInhouseReport['quantity'])); ?></span></td>
                                    <td class="text-end">৳<?php echo e(number_format($monthlyInhouseReport['subtotal'], 0)); ?></td>
                                    <td class="text-end">৳<?php echo e(number_format($monthlyInhouseReport['delivery'], 0)); ?></td>
                                    <td class="text-end fw-bold">৳<?php echo e(number_format($monthlyInhouseReport['total'], 0)); ?></td>
                                    <td class="text-end text-success fw-bold">৳<?php echo e(number_format($monthlyInhouseReport['paid'], 0)); ?></td>
                                    <td class="text-end text-danger fw-bold">৳<?php echo e(number_format($monthlyInhouseReport['due'], 0)); ?></td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                            <tfoot class="table-secondary">
                                <?php
                                    $totalParcels = array_sum(array_column($monthlyCourierReport, 'parcels')) + $monthlyInhouseReport['parcels'];
                                    $totalQuantity = array_sum(array_column($monthlyCourierReport, 'quantity')) + $monthlyInhouseReport['quantity'];
                                    $totalSubtotal = array_sum(array_column($monthlyCourierReport, 'subtotal')) + $monthlyInhouseReport['subtotal'];
                                    $totalDelivery = array_sum(array_column($monthlyCourierReport, 'delivery')) + $monthlyInhouseReport['delivery'];
                                    $totalTotal = array_sum(array_column($monthlyCourierReport, 'total')) + $monthlyInhouseReport['total'];
                                    $totalPaid = array_sum(array_column($monthlyCourierReport, 'paid')) + $monthlyInhouseReport['paid'];
                                    $totalDue = array_sum(array_column($monthlyCourierReport, 'due')) + $monthlyInhouseReport['due'];
                                ?>
                                <tr>
                                    <th colspan="2" class="text-end">GRAND TOTAL</th>
                                    <th class="text-center"><?php echo e($totalParcels); ?></th>
                                    <th class="text-center"><?php echo e(number_format($totalQuantity)); ?></th>
                                    <th class="text-end">৳<?php echo e(number_format($totalSubtotal, 0)); ?></th>
                                    <th class="text-end">৳<?php echo e(number_format($totalDelivery, 0)); ?></th>
                                    <th class="text-end">৳<?php echo e(number_format($totalTotal, 0)); ?></th>
                                    <th class="text-end text-success">৳<?php echo e(number_format($totalPaid, 0)); ?></th>
                                    <th class="text-end text-danger">৳<?php echo e(number_format($totalDue, 0)); ?></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
<?php if($adminhasFullAccess): ?>
<!-- This Month's Summary -->
<div class="row">
    <div class="col-xl-12 col-lg-12 col-md-12">
        <div class="card">
            <div class="card-body">
                <div class="stat-widget-one">

                    <!-- Icon -->
                    <div class="stat-icon dib">
                        <i class="fa fa-calendar text-primary border-primary"
                           style="font-size:32px;"></i>
                    </div>

                    <div class="stat-content dib" style="width:calc(100% - 70px);">

                        <!-- Title -->
                        <div class="stat-text"
                             style="font-size:22px; font-weight:800; color:#222; margin-bottom:8px;">
                            This Month's Summary
                        </div>

                        <!-- Total Summary -->
                        <div class="stat-sub"
                             style="font-size:17px; font-weight:700; line-height:1.9; color:#222;">

                            <span style="color:#34495e;">
                                Total Parcel:
                                <strong style="font-size:20px;">
                                    <?php echo e(array_sum(array_column($monthData, 'invoices')) + $monthInhouse['invoices']); ?>

                                </strong>
                            </span>

                            <span style="margin-left:10px; color:#555;">|</span>

                            <span style="color:#222;">
                                Total Qty:
                                <strong style="font-size:20px;">
                                    <?php echo e(number_format(array_sum(array_column($monthData, 'quantity')) + $monthInhouse['quantity'], 0)); ?>

                                </strong>
                            </span>

                            <span style="margin-left:10px; color:#555;">|</span>

                            <span style="color:#8e44ad;">
                                Price:
                                <strong style="font-size:20px;">
                                    ৳<?php echo e(number_format(array_sum(array_column($monthData, 'subtotal')) + $monthInhouse['subtotal'], 0)); ?>

                                </strong>
                            </span>

                            <span style="margin-left:10px; color:#555;">|</span>

                            <span style="color:#e67e22;">
                                Delivery:
                                <strong style="font-size:20px;">
                                    ৳<?php echo e(number_format(array_sum(array_column($monthData, 'delivery')) + $monthInhouse['delivery'], 0)); ?>

                                </strong>
                            </span>

                            <span style="margin-left:10px; color:#555;">|</span>

                            <span style="color:#2c3e50;">
                                Total:
                                <strong style="font-size:20px;">
                                    ৳<?php echo e(number_format(array_sum(array_column($monthData, 'revenue')) + $monthInhouse['revenue'], 0)); ?>

                                </strong>
                            </span>

                            <span style="margin-left:10px; color:#555;">|</span>

                            <span style="color:#27ae60;">
                                Paid:
                                <strong style="font-size:20px;">
                                    ৳<?php echo e(number_format(array_sum(array_column($monthData, 'paid')) + $monthInhouse['paid'], 0)); ?>

                                </strong>
                            </span>

                        </div>

                        <hr style="margin:15px 0; border-top:2px solid #eee;">

                        <!-- Courier Details -->
                        <?php $__currentLoopData = $monthData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courier => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php
                                $courierLower = strtolower($courier);

                                if (strpos($courierLower, 'pathao') !== false) {
                                    $courierColor = '#e74c3c';
                                    $courierBg = '#fff1f0';
                                } elseif (strpos($courierLower, 'redx') !== false) {
                                    $courierColor = '#c0392b';
                                    $courierBg = '#fff5f5';
                                } else {
                                    $courierColor = '#3498db';
                                    $courierBg = '#f0f8ff';
                                }
                            ?>

                            <div class="stat-sub"
                                 style="
                                    font-size:17px;
                                    font-weight:700;
                                    line-height:2;
                                    margin-bottom:8px;
                                    padding:8px 12px;
                                    background:<?php echo e($courierBg); ?>;
                                    border-left:5px solid <?php echo e($courierColor); ?>;
                                    border-radius:4px;
                                 ">

                                <!-- Courier Name -->
                                <strong style="
                                    color:<?php echo e($courierColor); ?>;
                                    font-size:20px;
                                    font-weight:900;
                                ">
                                    <?php echo e($courier); ?>

                                </strong>

                                <span style="color:#777;"> --- </span>

                                <!-- Qty -->
                                <span style="color:#222;">
                                    Qty:
                                    <strong style="font-size:19px;">
                                        <?php echo e(number_format($data['quantity'], 0)); ?>

                                    </strong>
                                </span>

                                <span style="color:#aaa;"> | </span>

                                <!-- Price -->
                                <span style="color:#8e44ad;">
                                    Price:
                                    <strong style="font-size:19px;">
                                        ৳<?php echo e(number_format($data['subtotal'] ?? 0, 0)); ?>

                                    </strong>
                                </span>

                                <span style="color:#aaa;"> | </span>

                                <!-- Delivery -->
                                <span style="color:#e67e22;">
                                    Delivery:
                                    <strong style="font-size:19px;">
                                        ৳<?php echo e(number_format($data['delivery'] ?? 0, 0)); ?>

                                    </strong>
                                </span>

                                <span style="color:#aaa;"> | </span>

                                <!-- Total -->
                                <span style="color:#2c3e50;">
                                    Total:
                                    <strong style="font-size:20px;">
                                        ৳<?php echo e(number_format($data['revenue'], 0)); ?>

                                    </strong>
                                </span>

                                <span style="color:#aaa;"> | </span>

                                <!-- Paid -->
                                <span style="color:#27ae60;">
                                    Paid:
                                    <strong style="font-size:19px;">
                                        ৳<?php echo e(number_format($data['paid'] ?? 0, 0)); ?>

                                    </strong>
                                </span>

                                <span style="color:#aaa;"> | </span>

                                <!-- Parcels -->
                                <span style="color:#34495e;">
                                    Parcels:
                                    <strong style="font-size:19px;">
                                        <?php echo e(number_format($data['invoices'] ?? 0, 0)); ?>

                                    </strong>
                                </span>

                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <!-- In House -->
                        <?php if($monthInhouse['invoices'] > 0): ?>

                            <hr style="margin:12px 0; border-top:2px solid #eee;">

                            <div class="stat-sub"
                                 style="
                                    font-size:17px;
                                    font-weight:700;
                                    line-height:2;
                                    padding:8px 12px;
                                    background:#edfff4;
                                    border-left:5px solid #2ecc71;
                                    border-radius:4px;
                                 ">

                                <!-- In House Name -->
                                <strong style="
                                    color:#27ae60;
                                    font-size:20px;
                                    font-weight:900;
                                ">
                                    In House
                                </strong>

                                <span style="color:#777;"> --- </span>

                                <!-- Qty -->
                                <span style="color:#222;">
                                    Qty:
                                    <strong style="font-size:19px;">
                                        <?php echo e(number_format($monthInhouse['quantity'], 0)); ?>

                                    </strong>
                                </span>

                                <span style="color:#aaa;"> | </span>

                                <!-- Price -->
                                <span style="color:#8e44ad;">
                                    Price:
                                    <strong style="font-size:19px;">
                                        ৳<?php echo e(number_format($monthInhouse['subtotal'] ?? 0, 0)); ?>

                                    </strong>
                                </span>

                                <span style="color:#aaa;"> | </span>

                                <!-- Delivery -->
                                <span style="color:#e67e22;">
                                    Delivery:
                                    <strong style="font-size:19px;">
                                        ৳<?php echo e(number_format($monthInhouse['delivery'] ?? 0, 0)); ?>

                                    </strong>
                                </span>

                                <span style="color:#aaa;"> | </span>

                                <!-- Total -->
                                <span style="color:#27ae60;">
                                    Total:
                                    <strong style="font-size:20px;">
                                        ৳<?php echo e(number_format($monthInhouse['revenue'], 0)); ?>

                                    </strong>
                                </span>

                                <span style="color:#aaa;"> | </span>

                                <!-- Paid -->
                                <span style="color:#16a085;">
                                    Paid:
                                    <strong style="font-size:19px;">
                                        ৳<?php echo e(number_format($monthInhouse['paid'] ?? 0, 0)); ?>

                                    </strong>
                                </span>

                                <span style="color:#aaa;"> | </span>

                                <!-- Parcels -->
                                <span style="color:#34495e;">
                                    Parcels:
                                    <strong style="font-size:19px;">
                                        <?php echo e(number_format($monthInhouse['invoices'] ?? 0, 0)); ?>

                                    </strong>
                                </span>

                            </div>

                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
</div>

<style>
    .stat-widget-one {
        padding: 15px 0;
    }
    .stat-widget-one .stat-icon {
        display: inline-block;
        width: 60px;
        height: 60px;
        line-height: 60px;
        text-align: center;
        border-radius: 50%;
        margin-right: 15px;
        font-size: 24px;
    }
    .stat-widget-one .stat-content {
        display: inline-block;
        vertical-align: middle;
    }
    .stat-widget-one .stat-text {
        font-size: 14px;
        color: #868e96;
        margin-bottom: 5px;
    }
    .stat-widget-one .stat-digit {
        font-size: 22px;
        font-weight: 600;
    }
    .stat-widget-one .stat-sub {
        font-size: 12px;
        font-weight: 500;
        color: #333;
    }
    .card {
        border-radius: 10px;
        box-shadow: 0 0 20px rgba(0,0,0,0.08);
        margin-bottom: 30px;
    }
    .card-header {
        border-bottom: 1px solid #eee;
        background: #fff;
    }
    .badge-success {
        background-color: #28a745;
    }
    .badge-warning {
        background-color: #ffc107;
    }
    .badge-danger {
        background-color: #dc3545;
    }
    .badge-info {
        background-color: #17a2b8;
    }
    .table td {
        vertical-align: middle;
    }
</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\custom_pos_taxtile\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>