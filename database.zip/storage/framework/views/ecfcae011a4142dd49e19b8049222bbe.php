



<?php $__env->startSection('main_content'); ?>

<div class="content mt-3">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">
                    <i class="fa fa-calendar-check mr-2"></i>
                    Mark Attendance - <?php echo e($today->format('d M, Y')); ?>

                    <?php if($isFriday): ?>
                        <span class="badge badge-warning ml-2">Friday</span>
                    <?php endif; ?>
                </h5>
            </div>
            <div class="card-body">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('admin.attendance.store')); ?>" method="POST" id="attendanceForm">
                    <?php echo csrf_field(); ?>
                    
                    <div class="row mb-4">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="attendance_date">Attendance Date <span class="text-danger">*</span></label>
                                <input type="date" 
                                       class="form-control <?php $__errorArgs = ['attendance_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="attendance_date" 
                                       name="attendance_date" 
                                       value="<?php echo e(old('attendance_date', $today->format('Y-m-d'))); ?>" 
                                       required>
                                <?php $__errorArgs = ['attendance_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Apply to All</label>
                                <div class="d-flex">
                                    <div class="custom-control custom-checkbox mr-3">
                                        <input type="checkbox" class="custom-control-input" id="is_friday" name="is_friday" value="1"
                                               <?php echo e(old('is_friday', $isFriday) ? 'checked' : ''); ?>>
                                        <label class="custom-control-label" for="is_friday">
                                            <span class="badge badge-secondary">Friday</span>
                                        </label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="is_govt_holiday" name="is_govt_holiday" value="1"
                                               <?php echo e(old('is_govt_holiday') ? 'checked' : ''); ?>>
                                        <label class="custom-control-label" for="is_govt_holiday">
                                            <span class="badge badge-primary">Govt. Holiday</span>
                                        </label>
                                    </div>
                                </div>
                                <small class="text-muted">These will apply to all users</small>
                            </div>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-bordered table-hover" id="attendanceTable">
                            <thead class="thead-light">
                                <tr>
                                    <th width="50">#</th>
                                    <th>User Name</th>
                                    <th>Email</th>
                                    <th width="120">In Time</th>
                                    <th width="120">Out Time</th>
                                    <th width="120">On Leave</th>
                                    <th>Note</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td>
                                            <input type="hidden" name="user_data[<?php echo e($index); ?>][user_id]" value="<?php echo e($user->id); ?>">
                                            <div class="d-flex align-items-center">
                                                <div class="avatar-circle bg-info text-white mr-2" 
                                                     style="width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px;">
                                                    <?php echo e(strtoupper(substr($user->name, 0, 2))); ?>

                                                </div>
                                                <div>
                                                    <strong><?php echo e($user->name); ?></strong>
                                                    <?php if($user->email): ?>
                                                        <br><small class="text-muted"><?php echo e($user->email); ?></small>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td><span class="badge badge-info"><?php echo e($user->email); ?></span></td>
                                        <td>
                                            <input type="time" 
                                                   class="form-control form-control-sm time-input" 
                                                   name="user_data[<?php echo e($index); ?>][in_time]" 
                                                   value="<?php echo e(old('user_data.' . $index . '.in_time')); ?>">
                                        </td>
                                        <td>
                                            <input type="time" 
                                                   class="form-control form-control-sm time-input" 
                                                   name="user_data[<?php echo e($index); ?>][out_time]" 
                                                   value="<?php echo e(old('user_data.' . $index . '.out_time')); ?>">
                                        </td>
                                        <td class="text-center">
                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" 
                                                       class="custom-control-input leave-checkbox" 
                                                       id="leave_<?php echo e($user->id); ?>" 
                                                       name="users_on_leave[]" 
                                                       value="<?php echo e($user->id); ?>"
                                                       <?php echo e(old('users_on_leave') && in_array($user->id, old('users_on_leave')) ? 'checked' : ''); ?>>
                                                <label class="custom-control-label" for="leave_<?php echo e($user->id); ?>">Leave</label>
                                            </div>
                                        </td>
                                        <td>
                                            <input type="text" 
                                                   class="form-control form-control-sm" 
                                                   name="user_data[<?php echo e($index); ?>][note]" 
                                                   placeholder="Note (optional)"
                                                   value="<?php echo e(old('user_data.' . $index . '.note')); ?>">
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">
                                            <div class="py-3">
                                                <i class="fa fa-users fa-2x text-muted mb-2"></i>
                                                <h6>No active users found</h6>
                                                <p class="text-muted mb-0">Please add users first.</p>
                                                <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-primary btn-sm mt-2">
                                                    <i class="fa fa-plus"></i> Add User
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="form-group mt-4">
                        <button type="submit" class="btn btn-primary" id="submitBtn">
                            <i class="fa fa-save"></i> Save Attendance
                        </button>
                        <a href="<?php echo e(route('admin.attendance.index')); ?>" class="btn btn-secondary">
                            <i class="fa fa-times"></i> Cancel
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
    .avatar-circle {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        font-weight: bold;
        flex-shrink: 0;
    }
    
    .time-input {
        width: 120px !important;
    }
    
    #attendanceTable td {
        vertical-align: middle;
    }
</style>

<script>
$(document).ready(function() {
    // When leave checkbox is checked, clear and disable time inputs
    $('.leave-checkbox').on('change', function() {
        const row = $(this).closest('tr');
        if ($(this).is(':checked')) {
            row.find('.time-input').val('').prop('disabled', true);
        } else {
            row.find('.time-input').prop('disabled', false);
        }
    });

    // Initialize leave checkboxes state
    $('.leave-checkbox:checked').each(function() {
        $(this).closest('tr').find('.time-input').prop('disabled', true);
    });

    // Validate form before submit
    $('#attendanceForm').on('submit', function(e) {
        let hasError = false;
        let errorMessages = [];
        
        // Check if attendance_date is set
        if (!$('#attendance_date').val()) {
            hasError = true;
            errorMessages.push('Please select an attendance date.');
        }
        
        if (hasError) {
            e.preventDefault();
            alert(errorMessages.join('\n'));
        }
    });
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\custom_pos_taxtile\resources\views/admin/attendance/create.blade.php ENDPATH**/ ?>