<div class="table-responsive">
    <table class="table table-hover">
        <thead>
            <tr>
                <th>ID</th>
                <th>Customer</th>
                <th>Contact</th>
                <th>Address</th>
                <th>Merchant Id</th>
                <th>Area</th>
                <th>Status</th>
                <th>Notes</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <!-- ID Column -->
                <td><?php echo e($c->id); ?></td>

                <!-- Customer Name Column -->
                <td>
                    <div class="d-flex align-items-center">
                        <div class="avatar-circle bg-primary text-white mr-3">
                            <?php echo e(substr($c->name, 0, 1)); ?>

                        </div>
                        <div>
                            <strong><?php echo e($c->name); ?></strong>
                            <div class="text-muted small">
                                <?php echo e($c->created_at->format('M d, Y')); ?>

                            </div>
                        </div>
                    </div>
                </td>

                <!-- Contact Column -->
                <td>
                    <?php if($c->phone_number_1): ?>
                    <div class="mb-1">
                        <i class="fa fa-phone text-primary mr-2"></i>
                        <?php echo e($c->phone_number_1); ?>

                    </div>
                    <?php endif; ?>
                    <?php if($c->phone_number_2): ?>
                    <div class="text-muted">
                        <i class="fa fa-phone mr-2"></i>
                        <?php echo e($c->phone_number_2); ?>

                    </div>
                    <?php endif; ?>
                </td>

                <!-- Address Column -->
                <td>
                    <i class="fa fa-map-marker-alt text-danger mr-2"></i>
                    <?php echo e(Str::limit($c->full_address, 30)); ?>

                </td>
                
                <!-- Merchant ID Column -->
                <td>
                    <?php if($c->merchant_order_id): ?>
                        <i class="fa fa-id-card text-info mr-2"></i>
                        <?php echo e($c->merchant_order_id); ?>

                    <?php else: ?>
                        <span class="text-muted">No ID</span>
                    <?php endif; ?>
                </td>
                
                <!-- Area Column -->
                <td>
                    <?php if($c->delivery_area): ?>
                        <i class="fa fa-map-marker-alt text-success mr-2"></i>
                        <?php echo e(Str::limit($c->delivery_area, 25)); ?>

                    <?php else: ?>
                        <span class="text-muted">No area</span>
                    <?php endif; ?>
                </td>

                <!-- Status Column -->
                <td>
                    <span class="badge <?php echo e($c->status == 'active' ? 'badge-success' : 'badge-danger'); ?>">
                        <?php echo e(ucfirst($c->status)); ?>

                    </span>
                </td>

                <!-- Notes Column -->
                <td>
                    <?php if($c->note): ?>
                    <i class="fa fa-sticky-note text-warning mr-1"></i>
                    <?php echo e(Str::limit($c->note, 20)); ?>

                    <?php else: ?>
                    <span class="text-muted">No notes</span>
                    <?php endif; ?>
                </td>

                <!-- Actions Column -->
                <td>
                    <div class="btn-group" role="group">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view customers')): ?>
                        <button type="button" class="btn btn-sm btn-info mr-1" 
                                data-toggle="modal" data-target="#viewModal<?php echo e($c->id); ?>"
                                title="View">
                            <i class="fa fa-eye"></i>
                        </button>
                        <?php endif; ?>
                        
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit customers')): ?>
                        <a href="<?php echo e(route('admin.customers.edit', $c->id)); ?>" 
                           class="btn btn-sm btn-warning mr-1"
                           title="Edit">
                            <i class="fa fa-edit"></i>
                        </a>
                        <?php endif; ?>
                        
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete customers')): ?>
                        <form action="<?php echo e(route('admin.customers.destroy', $c->id)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" 
                                    class="btn btn-sm btn-danger"
                                    title="Delete"
                                    onclick="return confirm('Are you sure?')">
                                <i class="fa fa-trash"></i>
                            </button>
                        </form>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>

            <!-- View Modal -->
            <div class="modal fade" id="viewModal<?php echo e($c->id); ?>" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Customer Details</h5>
                            <button type="button" class="close" data-dismiss="modal">
                                <span>&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="text-center mb-4">
                                <div class="avatar-circle bg-primary text-white mx-auto" style="width: 60px; height: 60px; font-size: 24px;">
                                    <?php echo e(substr($c->name, 0, 1)); ?>

                                </div>
                                <h5 class="mt-2"><?php echo e($c->name); ?></h5>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <p><strong>Primary Phone:</strong><br><?php echo e($c->phone_number_1); ?></p>
                                    <?php if($c->phone_number_2): ?>
                                    <p><strong>Secondary Phone:</strong><br><?php echo e($c->phone_number_2); ?></p>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-6">
                                    <p><strong>Created:</strong><br><?php echo e($c->created_at->format('M d, Y')); ?></p>
                                    <p><strong>Updated:</strong><br><?php echo e($c->updated_at->format('M d, Y')); ?></p>
                                </div>
                            </div>
                            
                            <p><strong>Address:</strong><br><?php echo e($c->full_address); ?></p>
                            <p><strong>Merchant ID:</strong><br><?php echo e($c->merchant_order_id ?: 'Not set'); ?></p>
                            <p><strong>Area:</strong><br><?php echo e($c->delivery_area ?: 'Not set'); ?></p>
                            
                            <?php if($c->note): ?>
                            <p><strong>Notes:</strong><br><?php echo e($c->note); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <a href="<?php echo e(route('admin.customers.edit', $c->id)); ?>" class="btn btn-primary">Edit</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="9" class="text-center py-4">
                    <i class="fa fa-users fa-2x text-muted mb-2"></i>
                    <p>No customers found</p>
                    <a href="<?php echo e(route('admin.customers.create')); ?>" class="btn btn-primary btn-sm">
                        Add First Customer
                    </a>
                </td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- Pagination -->
<div class="d-flex justify-content-between align-items-center mt-3">
    <div class="text-muted">
        Showing <?php echo e($customers->firstItem() ?? 0); ?> to <?php echo e($customers->lastItem() ?? 0); ?> of <?php echo e($customers->total()); ?> customers
    </div>
    <div>
        <?php echo e($customers->links('pagination::bootstrap-4')); ?>

    </div>
</div><?php /**PATH C:\xampp\htdocs\custom_pos_taxtile\resources\views/customers/partials/table.blade.php ENDPATH**/ ?>