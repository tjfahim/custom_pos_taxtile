

<div class="table-responsive">
    <table class="table table-hover" id="attendanceTable">
        <thead class="thead-light">
            <tr>
                <th>#</th>
                <th>User</th>
                <th>Email</th>
                <th>Date</th>
                <th>In Time</th>
                <th>Out Time</th>
                <th>Status</th>
                <th>Special</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($attendances->firstItem() + $key); ?></td>
                    <td>
                        <div class="d-flex align-items-center">
                            <div class="avatar-circle bg-info text-white mr-2" 
                                 style="width: 35px; height: 35px; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                                <?php echo e(strtoupper(substr($attendance->user->name ?? 'N/A', 0, 2))); ?>

                            </div>
                            <div>
                                <div class="font-weight-bold"><?php echo e($attendance->user->name ?? 'N/A'); ?></div>
                                <?php if($attendance->user->email ?? false): ?>
                                    <small class="text-muted"><?php echo e($attendance->user->email); ?></small>
                                <?php endif; ?>
                            </div>
                        </div>
                    </td>
                    <td>
                        <span class="badge badge-info"><?php echo e($attendance->user->email ?? 'N/A'); ?></span>
                    </td>
                    <td>
                        <?php echo e($attendance->attendance_date->format('d M, Y')); ?>

                    </td>
                    <td>
                        <?php if($attendance->in_time): ?>
                            <span class="badge badge-success"><?php echo e($attendance->formatted_in_time); ?></span>
                        <?php else: ?>
                            <span class="text-muted">-</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($attendance->out_time): ?>
                            <span class="badge badge-danger"><?php echo e($attendance->formatted_out_time); ?></span>
                        <?php else: ?>
                            <span class="text-muted">-</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php echo $attendance->status_badge; ?>

                    </td>
                    <td>
                        <?php if($attendance->is_friday): ?>
                            <span class="badge badge-secondary" title="Friday">📅 Fri</span>
                        <?php endif; ?>
                        <?php if($attendance->is_govt_holiday): ?>
                            <span class="badge badge-primary" title="Government Holiday">🏛️ Holiday</span>
                        <?php endif; ?>
                        <?php if($attendance->on_leave): ?>
                            <span class="badge badge-dark" title="On Leave">🏖️ Leave</span>
                        <?php endif; ?>
                        <?php if(!$attendance->is_friday && !$attendance->is_govt_holiday && !$attendance->on_leave): ?>
                            <span class="text-muted">-</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="btn-group btn-group-sm" role="group">
                            <a href="<?php echo e(route('admin.attendance.edit', $attendance->id)); ?>" 
                               class="btn btn-info btn-sm" 
                               title="Edit Attendance">
                                <i class="fa fa-edit"></i>
                            </a>
                            
                            <button type="button" 
                                    class="btn btn-danger btn-sm" 
                                    onclick="confirmDelete(<?php echo e($attendance->id); ?>, '<?php echo e($attendance->user->name ?? 'Unknown'); ?>', '<?php echo e($attendance->attendance_date->format('Y-m-d')); ?>')"
                                    title="Delete Attendance">
                                <i class="fa fa-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="9" class="text-center">
                        <div class="py-4">
                            <i class="fa fa-calendar fa-3x text-muted mb-3"></i>
                            <h5>No Attendance Records Found</h5>
                            <p class="text-muted">No attendance records for the selected date.</p>
                            <a href="<?php echo e(route('admin.attendance.create')); ?>" class="btn btn-primary btn-sm">
                                <i class="fa fa-plus"></i> Mark Attendance
                            </a>
                        </div>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- Pagination -->
<?php if($attendances->hasPages()): ?>
<div class="mt-3 d-flex justify-content-between align-items-center">
    <div>
        Showing <?php echo e($attendances->firstItem() ?? 0); ?> to <?php echo e($attendances->lastItem() ?? 0); ?> of <?php echo e($attendances->total()); ?> records
    </div>
    <div>
        <?php echo e($attendances->appends(['search' => request('search'), 'date' => request('date')])->links()); ?>

    </div>
</div>
<?php endif; ?>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm Delete</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete attendance record for <strong id="deleteUserName"></strong> on <strong id="deleteDate"></strong>?</p>
                <p class="text-muted">This action cannot be undone.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <form id="deleteForm" action="" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Delete Record</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function confirmDelete(id, name, date) {
    $('#deleteUserName').text(name);
    $('#deleteDate').text(date);
    $('#deleteForm').attr('action', "<?php echo e(route('admin.attendance.destroy', '')); ?>/" + id);
    $('#deleteModal').modal('show');
}
</script><?php /**PATH C:\xampp\htdocs\custom_pos_taxtile\resources\views/admin/attendance/partials/table.blade.php ENDPATH**/ ?>