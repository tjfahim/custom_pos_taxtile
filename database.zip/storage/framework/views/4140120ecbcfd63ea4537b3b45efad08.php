

<?php $__env->startSection('main_content'); ?>
<div class="content mt-3">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fa fa-cash-register"></i> POS - Create Invoice
                </h5>
            </div>
            <div class="card-body">
                <form id="posForm" action="<?php echo e(route('admin.invoices.store-pos')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    
                    <!-- Customer Section -->
                    <div class="card mb-3">
    <div class="card-header bg-light">
        <h6 class="mb-0"><i class="fa fa-user"></i> Customer Information</h6>
    </div>
    <div class="card-body" id="customerSection">
        <div class="row">
    <div class="col-md-4 mb-3">
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#customerModal">
            <i class="fa fa-search"></i> Select Customer
        </button>
        <input type="hidden" name="customer_id" id="customerId">
        <div class="mt-2">
            <small id="selectedCustomer" class="text-muted">No customer selected. .</small>
        </div>
    </div>

    <div class="col-md-8 mb-3">
        <div class="d-flex flex-wrap align-items-center justify-content-md-end" style="gap: 1.25rem;">
                <div class="form-group mb-0" style="min-width: 190px;">
                <label class="mb-0 small text-muted">Assign to Team Member</label>
                  <select name="team_id" id="teamMemberSelect" class="form-control">
    <option value="">-- Select Team Member --</option>

    <?php
        $currentUser = auth()->user();
        $teamMembers = $currentUser->teamMembers()->get();
        $recentTeamMemberId = session('recent_team_member_id');
    ?>

    <?php if($teamMembers->count() > 0): ?>
        <?php $__currentLoopData = $teamMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($member->id); ?>"
                <?php echo e(old('team_id', $recentTeamMemberId) == $member->id ? 'selected' : ''); ?>>
                <?php echo e($member->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <option value="" disabled>No team members added yet</option>
    <?php endif; ?>
</select>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" name="is_wholesale" id="isWholesale" value="1">
                <label class="form-check-label" for="isWholesale">Wholesale</label>
            </div>

            <div class="form-check">
                <input class="form-check-input" type="checkbox" name="is_inhouse_sale" id="isInhouseSale" value="1">
                <label class="form-check-label" for="isInhouseSale">In-house Sale</label>
            </div>

            <div class="form-group mb-0" style="min-width: 190px;">
                <label class="mb-0 small text-muted">Courier</label>
                <select name="courier_name" id="courierName" class="form-control form-control-sm">
                    <option value="Pathao" selected>Pathao (Default)</option>
                    <option value="Steadfast">Steadfast</option>
                    <option value="SA">SA</option>
                    <option value="SUNDORBAN">SUNDORBAN</option>
                    <option value="JANONI">JANONI</option>
                    <option value="REDEX">REDEX</option>
                    <option value="Exchange">Exchange</option>
                </select>
            </div>
        </div>
    </div>
</div>
  
                            <div class="row">
                                    <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Recipient Phone <span class="text-danger">*</span></label>
                                        <input type="text" name="recipient_phone" id="recipientPhone" class="form-control" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Recipient Name <span class="text-danger">*</span></label>
                                        <input type="text" name="recipient_name" id="recipientName" class="form-control" required>
                                    </div>
                                </div>
                            
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Secondary Phone</label>
                                        <input type="text" name="recipient_secondary_phone" id="recipientPhone2" class="form-control">
                                    </div>
                                </div>
                              <div class="col-md-4">
    <div class="form-group">
        <label>Merchant Order ID <span class="text-danger"></span></label>
        <div class="input-group">
            <input type="text" name="merchant_order_id" id="merchant_order_id" class="form-control" 
                   placeholder="Auto-generated 4-digit ID">
            <div class="input-group-append">
                <button type="button" class="btn btn-outline-secondary" id="refreshMerchantId" 
                        title="Refresh 4-digit ID">
                    <i class="fa fa-circle-o-notch"></i>
                </button>
            </div>
        </div>
    </div>
</div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Address</label>
                                        <textarea name="recipient_address" id="recipientAddress" rows="2" class="form-control" ></textarea>
                                    </div>
                                </div>
                               <div class="col-md-12">
   <div class="col-md-12" id="deliveryAreaWrapper">
    <div class="col-md-12">
        <div class="card mb-3" id="deliveryAreaCard">
            <div class="card-header bg-light">
                <h6 class="mb-0"><i class="fa fa-map-marker-alt"></i> Delivery Area</h6>
            </div>
            <div class="card-body">
            <div class="row">
                <!-- City Selection -->
                <div class="col-md-4">
                    <div class="form-group">
                        <label>City <span class="text-danger">*</span></label>
                        <select class="form-control select2-search" id="deliveryCitySelect" name="delivery_city">
                            <option value="">-- Select City --</option>
                        </select>
                        <div class="mt-1" id="cityLoading" style="display: none;">
                            <small class="text-primary">
                                <i class="fa fa-spinner fa-spin"></i> Loading cities...
                            </small>
                        </div>
                        <button type="button" id="refreshCities" class="btn btn-sm btn-link mt-1 p-0">
                            <i class="fa fa-redo"></i> Refresh Cities
                        </button>
                    </div>
                </div>
                
                <!-- Zone Selection -->
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Zone <span class="text-danger">*</span></label>
                        <select class="form-control select2-search" id="deliveryZoneSelect" name="delivery_zone" disabled>
                            <option value="">-- Select Zone --</option>
                        </select>
                        <div class="mt-1" id="zoneLoading" style="display: none;">
                            <small class="text-primary">
                                <i class="fa fa-spinner fa-spin"></i> Loading zones...
                            </small>
                        </div>
                    </div>
                </div>
                
                <!-- Area Selection -->
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Area </label>
                        <select class="form-control select2-search" id="deliveryAreaSelect" name="delivery_area_id" disabled>
                            <option value="">-- Select Area --</option>
                        </select>
                        <div class="mt-1" id="areaLoading" style="display: none;">
                            <small class="text-primary">
                                <i class="fa fa-spinner fa-spin"></i> Loading areas...
                            </small>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Manual Delivery Area Input (as fallback) -->
            <div class="row mt-3">
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Delivery Area <span class="text-danger">*</span></label>
                        <input type="text" name="delivery_area" id="deliveryArea" class="form-control" 
                               placeholder="City, Zone, Area (auto-filled based on selection)" required readonly>
                        <small class="text-muted">This field will auto-fill when you select city, zone, and area above</small>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>
</div>
                            </div>
                        </div>
                    </div>

                    <!-- Store & Delivery Info -->
                    <div class="row mb-3 pl-3 pr-3">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Store Location</label>
                                <select name="store_location" class="form-control" required>
                                    <option value="Faisal Textile FB">Faisal Textile FB</option>
                                    <option value="Faisal Textile Dhanmondi">Faisal Textile Dhanmondi</option>
                                    <option value="Faisal Textile">Faisal Textile</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Delivery Type <span class="text-danger">*</span></label>
                                <select name="delivery_type" class="form-control" required>
                                    <option value="Parcel">Parcel</option>
                                    <option value="Express">Express</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group mb-3">
                                <label>Status</label>
                                <select name="status" class="form-control" id="invoiceStatus">
                                    <option value="confirmed" selected>Confirmed</option>
                                    <option value="pending">Pending</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <?php echo $__env->make('invoices.partials.items-table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('invoices.partials.payment-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('invoices.partials.summary-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <!-- Form Actions -->
                    <div class="row mt-3">
                        <div class="col-md-12 text-right">
                            <button type="button" class="btn btn-success btn-lg" onclick="saveAndPrint()">
                                <i class="fa fa-save"></i> Save & Print Invoice
                            </button>
                            <button type="button" class="btn btn-secondary btn-lg" onclick="resetForm()">
                                Clear Form
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Include Modals -->
<?php echo $__env->make('invoices.partials.customer-select', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('invoices.partials.print-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<link href="<?php echo e(asset('css/pos-invoice.css')); ?>" rel="stylesheet">

<!-- Load all JavaScript modules in correct order -->
<script src="<?php echo e(asset('js/invoice-pos-items.js')); ?>"></script>
<script src="<?php echo e(asset('js/invoice-pos-return-items.js')); ?>"></script> 
<script src="<?php echo e(asset('js/invoice-pos-calculations.js')); ?>"></script>
<script src="<?php echo e(asset('js/invoice-pos-payments.js')); ?>"></script>
<script src="<?php echo e(asset('js/invoice-pos-delivery.js')); ?>"></script>
<script src="<?php echo e(asset('js/inhouse-sale-toggle.js')); ?>"></script>

<script src="<?php echo e(asset('js/address-city-zone-autofill.js')); ?>"></script>
<script src="<?php echo e(asset('js/delivery-charge-calculator.js')); ?>"></script>
<script src="<?php echo e(asset('js/fraud-check.js')); ?>"></script>
<script src="<?php echo e(asset('js/delivery-area-auto-select.js')); ?>"></script>
<script src="<?php echo e(asset('js/customer-auto.js')); ?>"></script>
<script src="<?php echo e(asset('js/invoice-pos-form-handler.js')); ?>"></script>
<script src="<?php echo e(asset('js/invoice-pos-core.js')); ?>"></script>

<!-- Global helper functions for inline onclick handlers -->
<script>
    // Make these functions globally available
    function togglePaymentDetails() {
        if (typeof InvoicePOS !== 'undefined' && InvoicePOS.Payments) {
            InvoicePOS.Payments.togglePaymentDetails();
        }
    }
    
    function printInvoice() {
        if (typeof InvoicePOS !== 'undefined' && InvoicePOS.FormHandler) {
            InvoicePOS.FormHandler.printInvoice();
        }
    }
    
    function createNewInvoice() {
        if (typeof InvoicePOS !== 'undefined' && InvoicePOS.FormHandler) {
            InvoicePOS.FormHandler.createNewInvoice();
        }
    }
    
    function saveAndPrint() {
        if (typeof InvoicePOS !== 'undefined' && InvoicePOS.FormHandler) {
            InvoicePOS.FormHandler.saveAndPrint();
        } else {
            console.error('InvoicePOS modules not loaded');
            alert('System not ready. Please refresh the page.');
        }
    }
    
    function resetForm() {
        if (typeof InvoicePOS !== 'undefined' && InvoicePOS.FormHandler) {
            InvoicePOS.FormHandler.resetForm();
        }
    }
        const recentTeamMemberId = <?php echo json_encode(session('recent_team_member_id'), 15, 512) ?>;

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\custom_pos_taxtile\resources\views/invoices/pos.blade.php ENDPATH**/ ?>