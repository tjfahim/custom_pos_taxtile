

<div class="table-responsive">
    <table class="table table-hover" id="staffTable">
        <thead class="thead-light">
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Designation</th>
                <th>Join Date</th>
                <th>Status</th>
                <th>Salary</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($staff->firstItem() + $key); ?></td>
                    <td>
                        <div class="d-flex align-items-center">
                            <div class="avatar-circle bg-primary text-white mr-2" style="width: 35px; height: 35px; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                                <?php echo e(strtoupper(substr($member->name, 0, 2))); ?>

                            </div>
                            <div>
                                <div class="font-weight-bold"><?php echo e($member->name); ?></div>
                                <?php if($member->email): ?>
                                    <small class="text-muted"><?php echo e($member->email); ?></small>
                                <?php endif; ?>
                            </div>
                        </div>
                    </td>
                    <td>
                        <span class="badge badge-info"><?php echo e($member->designation); ?></span>
                    </td>
                    <td>
                        <?php if($member->join_at): ?>
                            <?php echo e($member->join_at->format('d M, Y')); ?>

                        <?php else: ?>
                            <span class="text-muted">Not set</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php echo $member->status_badge; ?>

                    </td>
                    <td>
                        <strong><?php echo e($member->formatted_salary); ?></strong>
                    </td>
                    <td>
                        <div class="btn-group btn-group-sm" role="group">
                            <a href="<?php echo e(route('admin.staff.edit', $member->id)); ?>" 
                               class="btn btn-info btn-sm" 
                               title="Edit Staff">
                                <i class="fa fa-edit"></i>
                            </a>
                            
                            <button type="button" 
                                    class="btn btn-danger btn-sm" 
                                    onclick="confirmDelete(<?php echo e($member->id); ?>, '<?php echo e($member->name); ?>')"
                                    title="Delete Staff">
                                <i class="fa fa-trash"></i>
                            </button>
                            
                            <button type="button" 
                                    class="btn btn-warning btn-sm" 
                                    onclick="toggleStatus(<?php echo e($member->id); ?>)"
                                    title="Change Status">
                                <i class="fa fa-exchange"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center">
                        <div class="py-4">
                            <i class="fa fa-users fa-3x text-muted mb-3"></i>
                            <h5>No Staff Members Found</h5>
                            <p class="text-muted">Start by adding your first staff member.</p>
                            <a href="<?php echo e(route('admin.staff.create')); ?>" class="btn btn-primary btn-sm">
                                <i class="fa fa-plus"></i> Add Staff
                            </a>
                        </div>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- Pagination -->
<div class="mt-3 d-flex justify-content-between align-items-center">
    <div>
        Showing <?php echo e($staff->firstItem() ?? 0); ?> to <?php echo e($staff->lastItem() ?? 0); ?> of <?php echo e($staff->total()); ?> staff members
    </div>
    <div>
        <?php echo e($staff->appends(['search' => request('search')])->links()); ?>

    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm Delete</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete staff member <strong id="deleteStaffName"></strong>?</p>
                <p class="text-muted">This action cannot be undone.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <form id="deleteForm" action="" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Delete Staff</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Status Change Modal -->
<div class="modal fade" id="statusModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Change Status</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="statusForm" action="" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <label>Select New Status</label>
                        <select name="status" class="form-control" required>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                            <option value="on_leave">On Leave</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-warning">Update Status</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function confirmDelete(id, name) {
    $('#deleteStaffName').text(name);
    $('#deleteForm').attr('action', "<?php echo e(route('admin.staff.destroy', '')); ?>/" + id);
    $('#deleteModal').modal('show');
}

function toggleStatus(id) {
    $('#statusForm').attr('action', "<?php echo e(route('admin.staff.update-status', '')); ?>/" + id);
    $('#statusModal').modal('show');
}

// AJAX status update
$('#statusForm').on('submit', function(e) {
    e.preventDefault();
    const form = $(this);
    const url = form.attr('action');
    const data = form.serialize();
    
    $.ajax({
        url: url,
        method: 'POST',
        data: data,
        success: function(response) {
            if (response.success) {
                $('#statusModal').modal('hide');
                // Reload the table to reflect changes
                performSearch($('#searchInput').val());
                // Show success message
                showAlert('success', response.message);
            }
        },
        error: function(xhr) {
            showAlert('danger', xhr.responseJSON?.message || 'Failed to update status');
        }
    });
});

function showAlert(type, message) {
    const alertHtml = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    `;
    $('.content').prepend(alertHtml);
    setTimeout(() => {
        $('.alert').alert('close');
    }, 5000);
}
</script><?php /**PATH C:\xampp\htdocs\custom_pos_taxtile\resources\views/admin/staff/partials/table.blade.php ENDPATH**/ ?>